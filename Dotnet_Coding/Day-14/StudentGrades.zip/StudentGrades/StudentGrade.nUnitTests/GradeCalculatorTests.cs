namespace StudentGrades.nUnitTests
{
    public class GradeCalculatorTests
    {
        private GradeCalculator _gradeCalculator { get; set; } = null!;
        [SetUp]
        public void Setup()
        {
            _gradeCalculator=new GradeCalculator();
        }
        //[Test]
        [TestCase(92)]
        [TestCase(98)]
        [TestCase(60)]
        [TestCase(96)]
        public void GetGradeByPercentage_EqualTest(int percentage)
        {
            //assign
            //var percentage = 99;

            //act
            var Grade=_gradeCalculator.GetGradeByPercentage(percentage);
            //Assert.Pass();

            Assert.AreEqual("A", Grade);
            //Assert.AreEqual("B", Grade);
            //Assert.AreEqual("C", Grade);
        }
    }
}