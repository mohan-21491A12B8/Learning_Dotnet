﻿namespace Repository_Design_Pattern.Models
{
    public class StudentModel
    {
        public int rollNo {  get; set; }
        public string Name { get; set; }
        public string Gender { get; set; }
    }
}
