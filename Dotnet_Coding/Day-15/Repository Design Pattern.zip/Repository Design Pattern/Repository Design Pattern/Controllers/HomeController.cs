using System.Diagnostics;
using Microsoft.AspNetCore.Mvc;
using Repository_Design_Pattern.Models;
using Repository_Design_Pattern.Repository;

namespace Repository_Design_Pattern.Controllers
{
    public class HomeController : Controller
    {
        private readonly ILogger<HomeController> _logger;
        private readonly IStudent studentRepository=null;
        public HomeController(ILogger<HomeController> logger)
        {
            _logger = logger;
            studentRepository = new StudentRepository();
        }

        public List<StudentModel> getAllStudents()
        {
            return studentRepository.getAllStudents();

        }
        public IActionResult Index()
        {
            //var students = new List<StudentModel>
            //{
            //    new StudentModel{rollNo=1,Name="ram",Gender="male"},
            //    new StudentModel{rollNo=2,Name="sita",Gender="female"}
            //};
            //ViewData["myStudents"]=students;
            return View();
        }

        public IActionResult Privacy()
        {
            return View();
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
    }
}
