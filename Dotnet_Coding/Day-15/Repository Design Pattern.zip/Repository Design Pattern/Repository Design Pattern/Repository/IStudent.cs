﻿using Repository_Design_Pattern.Models;
namespace Repository_Design_Pattern.Repository
{
    public interface IStudent
    {
        List<StudentModel> getAllStudents();
        StudentModel getStudentByID(int id);
    }
}
