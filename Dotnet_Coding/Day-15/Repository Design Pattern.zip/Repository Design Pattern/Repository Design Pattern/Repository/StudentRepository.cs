﻿using Repository_Design_Pattern.Models;
using Repository_Design_Pattern.Repository;

namespace Repository_Design_Pattern.Repository
{
    public class StudentRepository: IStudent
    {
        List<StudentModel> IStudent.getAllStudents()
        {
            return DataSource();
        }
        StudentModel IStudent.getStudentByID(int id)
        {
            return DataSource().Where(x => x.rollNo == id).FirstOrDefault();
        }
        private List<StudentModel>DataSource()
        {
            return new List<StudentModel>
            {
                new StudentModel{rollNo=1,Name="ram",Gender="male"},
                new StudentModel{rollNo=2,Name="sita",Gender="female"}
            };
        }
    }
}
